import sys
sys.path.insert(0, "/home/claude/aula3")
from bpmn import *

W, H = 1850, 700
body = []
body.append(title(W/2, 30, "AS-IS — Repor estoque (processo manual, sem sistema)"))

POOL_X, POOL_W = 40, 1790
forn_y, forn_h = 55, 120
loja_y, loja_h = 210, 400

body.append(pool(POOL_X, forn_y, POOL_W, forn_h, "Fornecedor"))
body.append(pool(POOL_X, loja_y, POOL_W, loja_h, "Loja (Responsavel)"))

CY_FORN = forn_y + forn_h/2
CY_LOJA = loja_y + loja_h/2
HW, HH, HD, HE = 84, 37, 23, 20

x_start = 140
body.append(start_event(x_start, CY_LOJA, "Responsavel percebe visualmente que o produto esta acabando"))

x_gw1 = 340
body.append(gateway(x_gw1, CY_LOJA, "Ha tempo habil\npara repor antes\nde faltar?", kind="xor"))

x_ruptura = 340
y_ruptura = loja_y + 60
body.append(task(x_ruptura, y_ruptura, "Produto fica indisponivel na prateleira (ruptura)", kind="human", h=64))
x_end_ruptura = 560
y_end_ruptura = y_ruptura
body.append(end_event(x_end_ruptura, y_end_ruptura, "Venda perdida por falta de estoque"))

x_anota = 560
body.append(task(x_anota, CY_LOJA, "Responsavel anota o pedido em papel avulso / grupo de WhatsApp", kind="human"))

x_forn_recebe = 800
body.append(task(x_forn_recebe, CY_FORN, "Fornecedor recebe o pedido informalmente (telefone/WhatsApp)", kind="human"))

x_aguarda = 800
body.append(task(x_aguarda, CY_LOJA, "Responsavel aguarda a entrega, sem prazo formal combinado", kind="human"))

x_confere = 1000
body.append(task(x_confere, CY_LOJA, "Responsavel confere visualmente a mercadoria recebida", kind="human"))

x_atualiza = 1200
body.append(task(x_atualiza, CY_LOJA, "Responsavel atualiza a contagem no caderno, quando lembra", kind="human"))

x_data = 1200
y_data = loja_y + loja_h - 45
body.append(data_object(x_data, y_data, "Caderno de estoque (controle manual)"))
body.append(assoc(x_atualiza, CY_LOJA + HH, x_data, y_data - 40))

x_end = 1400
body.append(end_event(x_end, CY_LOJA, "Estoque reposto, sem registro confiavel"))

# flows
body.append(seq_flow([(x_start + HE, CY_LOJA), (x_gw1 - HD, CY_LOJA)]))
body.append(seq_flow([(x_gw1, CY_LOJA - HD), (x_gw1, y_ruptura + 32)], label="Nao", label_pos=(x_gw1 - 36, (CY_LOJA+y_ruptura)/2 + 10)))
body.append(seq_flow([(x_ruptura + 110, y_ruptura), (x_end_ruptura - HE, y_end_ruptura)]))
body.append(seq_flow([(x_gw1 + HD, CY_LOJA), (x_anota - HW, CY_LOJA)], label="Sim", label_pos=(x_gw1 + 55, CY_LOJA - 14)))

body.append(msg_flow([(x_anota, CY_LOJA - HH), (x_forn_recebe, CY_FORN + HE)], label="pede a mercadoria", label_pos=(x_anota+90, (CY_LOJA+CY_FORN)/2+10)))
body.append(msg_flow([(x_forn_recebe, CY_FORN + HE), (x_aguarda, CY_LOJA - HH)], label="confirma o pedido informalmente", label_pos=(x_forn_recebe+40,(CY_LOJA+CY_FORN)/2+45)))

body.append(seq_flow([(x_anota + HW, CY_LOJA), (x_aguarda - HW, CY_LOJA)]))
body.append(seq_flow([(x_aguarda + HW, CY_LOJA), (x_confere - HW, CY_LOJA)]))
body.append(seq_flow([(x_confere + HW, CY_LOJA), (x_atualiza - HW, CY_LOJA)]))
body.append(seq_flow([(x_atualiza + HW, CY_LOJA), (x_end - HE, CY_LOJA)]))

body.append(legend(60, 650, keys=("human", "gateway")))

svg = wrap_svg(W, H, "\n".join(body))
with open("/home/claude/aula3/diagrams/d3_asis_estoque.svg", "w", encoding="utf-8") as f:
    f.write(svg)
print("ok")
