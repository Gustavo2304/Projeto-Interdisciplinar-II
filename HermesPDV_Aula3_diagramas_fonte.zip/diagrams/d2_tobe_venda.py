import sys
sys.path.insert(0, "/home/claude/aula3")
from bpmn import *

W, H = 1950, 780
body = []
body.append(title(W/2, 30, "TO-BE — Registrar venda (com o sistema HermesPDV)"))

POOL_X, POOL_W = 40, 1890
cli_y, cli_h = 55, 140
loja_y, loja_h = 215, 480
lane_h = loja_h / 2

body.append(pool(POOL_X, cli_y, POOL_W, cli_h, "Cliente"))
body.append(pool(POOL_X, loja_y, POOL_W, loja_h, "Loja"))
body.append(lane_divider(POOL_X, POOL_W, loja_y + lane_h))
body.append(lane_label(POOL_X, loja_y, lane_h, "Atendente"))
body.append(lane_label(POOL_X, loja_y + lane_h, lane_h, "Sistema HermesPDV"))

CY_CLI = cli_y + cli_h / 2            # 125
CY_AT = loja_y + lane_h / 2           # 335
CY_SIS = loja_y + lane_h + lane_h / 2 # 575

HW = 84   # half width of a default task (w=168)
HH = 37   # half height of a default task (h=74)
HD = 23   # half size of gateway diamond (s=46)
HE = 20   # event radius

# ---------------- Cliente pool ----------------
x_start = 150
body.append(start_event(x_start, CY_CLI, "Cliente leva os produtos ao caixa"))

x_end_cli = 1830
body.append(end_event(x_end_cli, CY_CLI, "Cliente recebe o comprovante e sai da loja"))

# ---------------- Atendente lane ----------------
x_lanca = 330
body.append(task(x_lanca, CY_AT, "Atendente lanca os itens da venda no sistema (busca por nome/codigo)", kind="human", code="RF05 / RF17"))

x_paga = 740
body.append(task(x_paga, CY_AT, "Atendente informa a(s) forma(s) de pagamento", kind="human", code="RF07 / RF08"))

x_entrega = 1660
body.append(task(x_entrega, CY_AT, "Atendente entrega o comprovante ao cliente", kind="human", code="RF13"))

# ---------------- Sistema lane ----------------
x_calc = 540
body.append(task(x_calc, CY_SIS, "Sistema calcula subtotal, descontos e total", kind="system", code="RF06"))

x_gw1 = 940
body.append(gateway(x_gw1, CY_SIS, "Pagamento(s) cobrem o valor total?", kind="xor"))

x_baixa = 1130
body.append(task(x_baixa, CY_SIS, "Sistema registra a venda e da baixa automatica no estoque", kind="system", code="RF05 / RF09"))

x_gw2 = 1310
body.append(gateway(x_gw2, CY_SIS, "Estoque abaixo do minimo?", kind="xor"))

x_alerta = 1310
y_alerta = loja_y + loja_h - 45
body.append(task(x_alerta, y_alerta, "Sistema gera alerta de estoque baixo", kind="system", w=196, h=60, code="RF10 / RN07"))

x_comprov = 1510
body.append(task(x_comprov, CY_SIS, "Sistema emite o comprovante da venda", kind="system", code="RF13"))

x_gwAND = 1660
body.append(gateway(x_gwAND, CY_SIS, None, kind="and"))

x_end_sis = 1820
body.append(end_event(x_end_sis, CY_SIS, "Venda registrada no banco de dados"))

x_data = 1130
y_data = loja_y + loja_h - 45
# (kept clear: the alerta task occupies this row for x~1310; place data object further left)
x_data = 900
y_data = loja_y + loja_h - 48
body.append(data_object(x_data, y_data, "Produto / Estoque (tabela no banco de dados)"))
body.append(assoc(x_baixa, CY_SIS + HH, x_data, y_data - 40))

# ---------------- flows ----------------
# message: cliente -> atendente
body.append(msg_flow([(x_start, CY_CLI + HE), (x_lanca, loja_y)], label="leva os produtos ao caixa",
                      label_pos=(x_lanca - 70, loja_y - 12)))

# atendente lanca -> sistema calcula (cross-lane)
body.append(seq_flow([(x_lanca, CY_AT + HH), (x_lanca, CY_SIS), (x_calc - HW, CY_SIS)]))
# sistema calcula -> atendente informa pagamento (cross-lane back up)
body.append(seq_flow([(x_calc, CY_SIS - HH), (x_calc, CY_AT), (x_paga - HW, CY_AT)]))
# atendente informa pagamento -> gateway 1 (cross-lane down)
body.append(seq_flow([(x_paga, CY_AT + HH), (x_paga, CY_SIS), (x_gw1 - HD, CY_SIS)]))
# gateway1 "Nao" -> loops back to atendente informa pagamento
body.append(seq_flow([
    (x_gw1, CY_SIS - HD), (x_gw1, loja_y + lane_h - 18), (x_paga, loja_y + lane_h - 18), (x_paga, CY_AT + HH)
], label="Nao (valor incompleto)", label_pos=(x_paga + 70, loja_y + lane_h - 30)))
# gateway1 "Sim" -> baixa estoque
body.append(seq_flow([(x_gw1 + HD, CY_SIS), (x_baixa - HW, CY_SIS)], label="Sim", label_pos=(x_gw1 + 55, CY_SIS - 14)))

# baixa -> gateway2
body.append(seq_flow([(x_baixa + HW, CY_SIS), (x_gw2 - HD, CY_SIS)]))
# gateway2 "Nao" (estoque ok) -> comprovante (straight)
body.append(seq_flow([(x_gw2 + HD, CY_SIS), (x_comprov - HW, CY_SIS)], label="Nao", label_pos=(x_gw2 + 55, CY_SIS - 14)))
# gateway2 "Sim" -> alerta -> comprovante (from below)
body.append(seq_flow([(x_gw2, CY_SIS + HD), (x_gw2, y_alerta - 30), (x_alerta, y_alerta - 30)], label="Sim", label_pos=(x_gw2 + 10, y_alerta - 44)))
body.append(seq_flow([(x_alerta + 98, y_alerta), (x_comprov, y_alerta), (x_comprov, CY_SIS + HH)]))

# comprovante -> AND split
body.append(seq_flow([(x_comprov + HW, CY_SIS), (x_gwAND - HD, CY_SIS)]))
# AND -> end event (sistema)
body.append(seq_flow([(x_gwAND + HD, CY_SIS), (x_end_sis - HE, CY_SIS)]))
# AND -> atendente entrega (cross-lane up)
body.append(seq_flow([(x_gwAND, CY_SIS - HD), (x_gwAND, CY_AT), (x_entrega, CY_AT + HH)]))

# message: atendente entrega -> cliente end event
body.append(msg_flow([(x_entrega, CY_AT - HH), (x_end_cli, CY_CLI + HE)], label="entrega o comprovante",
                      label_pos=(x_entrega + 40, CY_AT - HH - 25)))

body.append(legend(60, 710, keys=("human", "system", "gateway")))

svg = wrap_svg(W, H, "\n".join(body))
with open("/home/claude/aula3/diagrams/d2_tobe_venda.svg", "w", encoding="utf-8") as f:
    f.write(svg)
print("ok")
