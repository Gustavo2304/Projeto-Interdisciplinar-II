import sys
sys.path.insert(0, "/home/claude/aula3")
from bpmn import *

W, H = 1720, 700
body = []

body.append(title(W/2, 30, "AS-IS — Registrar venda (processo manual, sem sistema)"))

# Pools
POOL_X, POOL_W = 40, 1660
cli_y, cli_h = 55, 150
loja_y, loja_h = 235, 330

body.append(pool(POOL_X, cli_y, POOL_W, cli_h, "Cliente"))
body.append(pool(POOL_X, loja_y, POOL_W, loja_h, "Loja (Atendente)"))

band = 30
CY_CLI = cli_y + cli_h/2      # 130
CY_LOJA = loja_y + loja_h/2   # 400
Y_UP = loja_y + 95            # branch "dinheiro" row
Y_DN = loja_y + loja_h - 95   # branch "cartao" row

# ---- Cliente lane elements ----
x_start = 140
body.append(start_event(x_start, CY_CLI, "Cliente decide comprar"))

x_leva = 330
body.append(task(x_leva, CY_CLI, "Cliente leva os produtos ate o caixa", kind="human"))

x_paga = 900
body.append(task(x_paga, CY_CLI-10, "Cliente recebe o valor total e escolhe a forma de pagamento", kind="human", h=86))

x_end_cli = 1560
body.append(end_event(x_end_cli, CY_CLI, "Cliente sai da loja (sem comprovante formal)"))

body.append(seq_flow([(x_start+20, CY_CLI), (x_leva-84, CY_CLI)]))
body.append(seq_flow([(x_paga+95, CY_CLI-10), (x_end_cli-20, CY_CLI)]))

# ---- Loja / Atendente lane elements ----
x_recebe = 330
body.append(task(x_recebe, CY_LOJA, "Atendente recebe os produtos no balcao", kind="human"))

x_verifica = 510
body.append(task(x_verifica, CY_LOJA, "Atendente verifica o preco de cada item (etiqueta ou memoria)", kind="human"))

x_soma = 690
body.append(task(x_soma, CY_LOJA, "Atendente soma os valores na calculadora", kind="human"))

x_informa = 900
body.append(task(x_informa, CY_LOJA, "Atendente informa o valor total ao cliente", kind="human"))

x_gw1 = 1045
body.append(gateway(x_gw1, CY_LOJA, "Forma de pagamento?", kind="xor"))

x_dinheiro = 1180
body.append(task(x_dinheiro, Y_UP, "Atendente calcula o troco de cabeca ou na calculadora", kind="human"))

x_cartao = 1180
body.append(task(x_cartao, Y_DN, "Atendente usa maquineta avulsa, sem integracao com o caixa", kind="human"))

x_gw2 = 1320
body.append(gateway(x_gw2, CY_LOJA, None, kind="xor"))

x_anota = 1420
body.append(task(x_anota, CY_LOJA, "Atendente anota a venda no caderno (produto, valor, pagamento)", kind="human"))

x_end_loja = 1580
body.append(end_event(x_end_loja, CY_LOJA, "Venda registrada apenas no papel"))

x_data = 1420
y_data = loja_y + loja_h - 10
body.append(data_object(x_data, y_data, "Caderno de vendas / estoque (controle manual)"))
body.append(assoc(x_anota, CY_LOJA+37, x_data, y_data-40))

# sequence flows Loja lane
body.append(seq_flow([(x_recebe+84, CY_LOJA), (x_verifica-84, CY_LOJA)]))
body.append(seq_flow([(x_verifica+84, CY_LOJA), (x_soma-84, CY_LOJA)]))
body.append(seq_flow([(x_soma+84, CY_LOJA), (x_informa-84, CY_LOJA)]))
body.append(seq_flow([(x_informa+84, CY_LOJA), (x_gw1-23, CY_LOJA)]))

body.append(seq_flow([(x_gw1, CY_LOJA-23), (x_gw1, Y_UP), (x_dinheiro-84, Y_UP)], label="Dinheiro", label_pos=(x_gw1+40, Y_UP-14)))
body.append(seq_flow([(x_gw1, CY_LOJA+23), (x_gw1, Y_DN), (x_cartao-84, Y_DN)], label="Cartao", label_pos=(x_gw1+40, Y_DN-14)))

body.append(seq_flow([(x_dinheiro+84, Y_UP), (x_gw2, Y_UP), (x_gw2, CY_LOJA-23)]))
body.append(seq_flow([(x_cartao+84, Y_DN), (x_gw2, Y_DN), (x_gw2, CY_LOJA+23)]))

body.append(seq_flow([(x_gw2+23, CY_LOJA), (x_anota-84, CY_LOJA)]))
body.append(seq_flow([(x_anota+84, CY_LOJA), (x_end_loja-20, CY_LOJA)]))

# message flows between pools
body.append(msg_flow([(x_leva, CY_CLI+37), (x_recebe, loja_y)], label="pede os produtos"))
body.append(msg_flow([(x_informa, loja_y), (x_paga-30, CY_CLI-10+43)], label="informa o total a pagar", label_pos=(x_paga-30, 198)))

body.append(legend(60, 650, keys=("human", "gateway")))

svg = wrap_svg(W, H, "\n".join(body))
with open("/home/claude/aula3/diagrams/d1_asis_venda.svg", "w", encoding="utf-8") as f:
    f.write(svg)
print("ok")
