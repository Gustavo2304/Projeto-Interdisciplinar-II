import sys
sys.path.insert(0, "/home/claude/aula3")
from bpmn import *

W, H = 1950, 800
body = []
body.append(title(W/2, 30, "TO-BE — Repor estoque (com o sistema HermesPDV)"))

POOL_X, POOL_W = 40, 1890
forn_y, forn_h = 55, 120
loja_y, loja_h = 210, 470
lane_h = loja_h / 2

body.append(pool(POOL_X, forn_y, POOL_W, forn_h, "Fornecedor"))
body.append(pool(POOL_X, loja_y, POOL_W, loja_h, "Loja"))
body.append(lane_divider(POOL_X, POOL_W, loja_y + lane_h))
body.append(lane_label(POOL_X, loja_y, lane_h, "Sistema HermesPDV"))
body.append(lane_label(POOL_X, loja_y + lane_h, lane_h, "Administrador / Gerente"))

CY_FORN = forn_y + forn_h/2
CY_SIS = loja_y + lane_h/2
CY_ADM = loja_y + lane_h + lane_h/2
HW, HH, HD, HE = 84, 37, 23, 20

# Sistema lane
x_monitora = 220
body.append(task(x_monitora, CY_SIS, "Sistema monitora o saldo apos cada venda registrada", kind="system", code="RF09"))

x_gw1 = 440
body.append(gateway(x_gw1, CY_SIS, "Estoque <= quantidade\nminima configurada?", kind="xor"))

x_alerta = 660
body.append(task(x_alerta, CY_SIS, "Sistema gera o alerta de estoque baixo e notifica o administrador", kind="system", code="RF10 / RN07"))

x_atualiza_sis = 1660
body.append(task(x_atualiza_sis, CY_SIS, "Sistema atualiza o saldo em estoque e encerra o alerta", kind="system", code="RF01 / RF09"))

x_end_sis = 1850
body.append(end_event(x_end_sis, CY_SIS, "Estoque atualizado no banco de dados"))

# Administrador lane
x_avalia = 660
body.append(task(x_avalia, CY_ADM, "Administrador avalia o alerta e decide repor o produto", kind="human"))

x_contata = 900
body.append(task(x_contata, CY_ADM, "Administrador contata o fornecedor e faz o pedido (fora do sistema)", kind="human"))

x_forn = 1150
body.append(task(x_forn, CY_FORN, "Fornecedor recebe o pedido e providencia a entrega", kind="human"))

x_confere = 1400
body.append(task(x_confere, CY_ADM, "Administrador confere a mercadoria recebida", kind="human"))

x_lanca = 1660
body.append(task(x_lanca, CY_ADM, "Administrador lanca a quantidade recebida no sistema", kind="human", code="RF01"))

# loop back from gateway "Nao" to monitoring (keeps cycling), routed below within the same lane
body.append(seq_flow([
    (x_gw1, CY_SIS + HD), (x_gw1, CY_SIS + 75), (x_monitora, CY_SIS + 75), (x_monitora, CY_SIS + HH)
], label="Nao (estoque normal)", label_pos=(x_monitora + 95, CY_SIS + 92)))

body.append(seq_flow([(x_monitora + HW, CY_SIS), (x_gw1 - HD, CY_SIS)]))
body.append(seq_flow([(x_gw1 + HD, CY_SIS), (x_alerta - HW, CY_SIS)], label="Sim", label_pos=(x_gw1 + 55, CY_SIS - 14)))

body.append(seq_flow([(x_alerta, CY_SIS + HH), (x_avalia, CY_ADM - HH)]))
body.append(seq_flow([(x_avalia + HW, CY_ADM), (x_contata - HW, CY_ADM)]))

body.append(msg_flow([(x_contata, CY_ADM - HH), (x_forn, CY_FORN + HE)], label="pedido de reposicao",
                      label_pos=(x_contata - 10, (CY_ADM+CY_FORN)/2 - 55)))
body.append(msg_flow([(x_forn, CY_FORN + HE), (x_confere, CY_ADM - HH)], label="entrega a mercadoria",
                      label_pos=(x_confere - 30, (CY_ADM+CY_FORN)/2 - 20)))

body.append(seq_flow([(x_confere + HW, CY_ADM), (x_lanca - HW, CY_ADM)]))
body.append(seq_flow([(x_lanca, CY_ADM - HH), (x_atualiza_sis, CY_SIS + HH)]))
body.append(seq_flow([(x_atualiza_sis + HW, CY_SIS), (x_end_sis - HE, CY_SIS)]))

body.append(legend(60, 710, keys=("human", "system", "gateway")))

svg = wrap_svg(W, H, "\n".join(body))
with open("/home/claude/aula3/diagrams/d4_tobe_estoque.svg", "w", encoding="utf-8") as f:
    f.write(svg)
print("ok")
