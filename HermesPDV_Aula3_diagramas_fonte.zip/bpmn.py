"""Small hand-rolled BPMN-ish SVG primitive library.

Not a general framework — just enough reusable shape emitters to hand-lay-out
a handful of legible BPMN diagrams for an academic deliverable.
"""
import textwrap

FONT = "Calibri, 'Segoe UI', Arial, sans-serif"

COLOR_HUMAN = "#DCEBFC"      # light blue fill for human/manual tasks
COLOR_HUMAN_BORDER = "#2B5FA8"
COLOR_SYSTEM = "#DDF3E4"     # light green fill for system tasks
COLOR_SYSTEM_BORDER = "#1F8A4C"
COLOR_GATEWAY = "#FFF3CD"
COLOR_GATEWAY_BORDER = "#8A6D1F"
COLOR_EVENT_START = "#E3F6E8"
COLOR_EVENT_START_BORDER = "#1F8A4C"
COLOR_EVENT_END = "#FBE4E1"
COLOR_EVENT_END_BORDER = "#B3261E"
COLOR_DATA = "#FFFFFF"
COLOR_DATA_BORDER = "#555555"
COLOR_POOL_BORDER = "#333333"
COLOR_LABEL_BAND = "#EFEFEF"


def _wrap(text, width):
    lines = []
    for para in text.split("\n"):
        wrapped = textwrap.wrap(para, width=width) or [""]
        lines.extend(wrapped)
    return lines


def multiline_text(cx, cy, text, width_chars=20, font_size=12.5, bold=False, color="#111111", line_height=14.5):
    lines = _wrap(text, width_chars)
    n = len(lines)
    start_y = cy - (n - 1) * line_height / 2
    weight = "600" if bold else "400"
    out = []
    for i, line in enumerate(lines):
        y = start_y + i * line_height
        esc = (line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        out.append(
            f'<text x="{cx}" y="{y:.1f}" text-anchor="middle" dominant-baseline="middle" '
            f'font-family="{FONT}" font-size="{font_size}" font-weight="{weight}" fill="{color}">{esc}</text>'
        )
    return "\n".join(out)


def task(cx, cy, label, kind="human", w=168, h=74, code=None):
    fill = COLOR_SYSTEM if kind == "system" else COLOR_HUMAN
    border = COLOR_SYSTEM_BORDER if kind == "system" else COLOR_HUMAN_BORDER
    x, y = cx - w / 2, cy - h / 2
    svg = [f'<rect x="{x:.1f}" y="{y:.1f}" width="{w}" height="{h}" rx="10" ry="10" '
           f'fill="{fill}" stroke="{border}" stroke-width="2"/>']
    svg.append(multiline_text(cx, cy - (6 if code else 0), label, width_chars=21, font_size=12.3))
    if code:
        svg.append(f'<text x="{cx}" y="{cy + h/2 - 10}" text-anchor="middle" font-family="{FONT}" '
                    f'font-size="10.5" font-weight="700" fill="{border}">[{code}]</text>')
    return "\n".join(svg)


def start_event(cx, cy, label, r=20):
    svg = [f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{COLOR_EVENT_START}" '
           f'stroke="{COLOR_EVENT_START_BORDER}" stroke-width="2.3"/>']
    svg.append(multiline_text(cx, cy + r + 24, label, width_chars=19, font_size=11.6))
    return "\n".join(svg)


def end_event(cx, cy, label, r=20):
    svg = [f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{COLOR_EVENT_END}" '
           f'stroke="{COLOR_EVENT_END_BORDER}" stroke-width="4"/>']
    svg.append(multiline_text(cx, cy + r + 24, label, width_chars=19, font_size=11.6))
    return "\n".join(svg)


def gateway(cx, cy, label, kind="xor", s=46):
    h = s / 2
    pts = f"{cx},{cy-h} {cx+h},{cy} {cx},{cy+h} {cx-h},{cy}"
    svg = [f'<polygon points="{pts}" fill="{COLOR_GATEWAY}" stroke="{COLOR_GATEWAY_BORDER}" stroke-width="2.2"/>']
    mark = "X" if kind == "xor" else "+"
    svg.append(f'<text x="{cx}" y="{cy+1}" text-anchor="middle" dominant-baseline="middle" '
                f'font-family="{FONT}" font-size="21" font-weight="700" fill="{COLOR_GATEWAY_BORDER}">{mark}</text>')
    if label:
        svg.append(multiline_text(cx, cy - h - 20, label, width_chars=24, font_size=11.6, bold=True))
    return "\n".join(svg)


def data_object(cx, cy, label, w=66, h=80):
    x, y = cx - w / 2, cy - h / 2
    fold = 16
    path = (f"M{x},{y} L{x+w-fold},{y} L{x+w},{y+fold} L{x+w},{y+h} L{x},{y+h} Z")
    svg = [f'<path d="{path}" fill="{COLOR_DATA}" stroke="{COLOR_DATA_BORDER}" stroke-width="1.8"/>']
    svg.append(f'<path d="M{x+w-fold},{y} L{x+w-fold},{y+fold} L{x+w},{y+fold}" '
                f'fill="none" stroke="{COLOR_DATA_BORDER}" stroke-width="1.5"/>')
    svg.append(multiline_text(cx, cy + h / 2 + 22, label, width_chars=18, font_size=11))
    return "\n".join(svg)


def arrow_defs():
    return """
    <defs>
      <marker id="arrowSeq" markerWidth="11" markerHeight="11" refX="9" refY="4" orient="auto" markerUnits="userSpaceOnUse">
        <path d="M0,0 L9,4 L0,8 Z" fill="#222222"/>
      </marker>
      <marker id="arrowMsg" markerWidth="11" markerHeight="11" refX="9" refY="4" orient="auto" markerUnits="userSpaceOnUse">
        <path d="M0,0 L9,4 L0,8 Z" fill="none" stroke="#555555" stroke-width="1.3"/>
      </marker>
    </defs>
    """


def seq_flow(points, label=None, label_pos=None, dashed=False):
    """points: list of (x,y) forming an orthogonal polyline. Sequence flow = solid line, filled arrowhead."""
    pts = " ".join(f"{x},{y}" for x, y in points)
    dash = ' stroke-dasharray="7,4"' if dashed else ""
    svg = [f'<polyline points="{pts}" fill="none" stroke="#222222" stroke-width="1.8"{dash} '
           f'marker-end="url(#arrowSeq)"/>']
    if label:
        lx, ly = label_pos if label_pos else points[len(points)//2]
        svg.append(f'<rect x="{lx-5}" y="{ly-20}" width="{len(label)*6.6+10}" height="16" fill="white" opacity="0.85"/>')
        svg.append(f'<text x="{lx}" y="{ly-8}" font-family="{FONT}" font-size="11.3" font-weight="700" '
                    f'fill="#444400">{label}</text>')
    return "\n".join(svg)


def msg_flow(points, label=None, label_pos=None):
    """Message flow = dashed line with open arrowhead, between pools."""
    pts = " ".join(f"{x},{y}" for x, y in points)
    svg = [f'<circle cx="{points[0][0]}" cy="{points[0][1]}" r="4" fill="white" stroke="#555555" stroke-width="1.3"/>',
           f'<polyline points="{pts}" fill="none" stroke="#555555" stroke-width="1.6" stroke-dasharray="5,5" '
           f'marker-end="url(#arrowMsg)"/>']
    if label:
        lx, ly = label_pos if label_pos else points[len(points)//2]
        svg.append(f'<rect x="{lx-5}" y="{ly-20}" width="{len(label)*6.3+10}" height="16" fill="white" opacity="0.85"/>')
        svg.append(f'<text x="{lx}" y="{ly-8}" font-family="{FONT}" font-size="11" font-style="italic" '
                    f'fill="#555555">{label}</text>')
    return "\n".join(svg)


def assoc(x1, y1, x2, y2):
    """Dotted association line (task <-> data object), no arrowhead."""
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#666666" '
            f'stroke-width="1.3" stroke-dasharray="2,3"/>')


def pool(x, y, w, h, label, band_w=30):
    svg = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="white" stroke="{COLOR_POOL_BORDER}" stroke-width="2.2"/>']
    svg.append(f'<rect x="{x}" y="{y}" width="{band_w}" height="{h}" fill="{COLOR_LABEL_BAND}" stroke="{COLOR_POOL_BORDER}" stroke-width="2.2"/>')
    cx, cy = x + band_w / 2, y + h / 2
    svg.append(f'<text x="{cx}" y="{cy}" text-anchor="middle" dominant-baseline="middle" '
                f'font-family="{FONT}" font-size="14.5" font-weight="700" fill="#222222" '
                f'transform="rotate(-90 {cx} {cy})">{label}</text>')
    return "\n".join(svg)


def lane_divider(x, w, y, band_w=30):
    return f'<line x1="{x+band_w}" y1="{y}" x2="{x+w}" y2="{y}" stroke="{COLOR_POOL_BORDER}" stroke-width="1.4" stroke-dasharray="3,3"/>'


def lane_label(x, y, h, label, band_w=30, sub_w=24):
    cx, cy = x + band_w + sub_w / 2, y + h / 2
    svg = [f'<rect x="{x+band_w}" y="{y}" width="{sub_w}" height="{h}" fill="#F7F7F7" stroke="{COLOR_POOL_BORDER}" stroke-width="1.2"/>']
    svg.append(f'<text x="{cx}" y="{cy}" text-anchor="middle" dominant-baseline="middle" '
                f'font-family="{FONT}" font-size="12" font-weight="600" fill="#333333" '
                f'transform="rotate(-90 {cx} {cy})">{label}</text>')
    return "\n".join(svg)


def title(cx, y, text, size=19):
    return (f'<text x="{cx}" y="{y}" text-anchor="middle" font-family="{FONT}" '
            f'font-size="{size}" font-weight="700" fill="#111111">{text}</text>')


LEGEND_ITEMS = {
    "human": (COLOR_HUMAN, COLOR_HUMAN_BORDER, "Atividade humana"),
    "system": (COLOR_SYSTEM, COLOR_SYSTEM_BORDER, "Atividade do sistema (HermesPDV)"),
    "gateway": (COLOR_GATEWAY, COLOR_GATEWAY_BORDER, "Gateway de decisão (XOR)"),
}


def legend(x, y, keys=("human", "gateway")):
    items = [LEGEND_ITEMS[k] for k in keys]
    svg = []
    cy = y
    for fill, border, label in items:
        svg.append(f'<rect x="{x}" y="{cy-10}" width="22" height="20" rx="4" fill="{fill}" stroke="{border}" stroke-width="1.8"/>')
        svg.append(f'<text x="{x+30}" y="{cy+4}" font-family="{FONT}" font-size="12" fill="#222222">{label}</text>')
        cy += 26
    return "\n".join(svg)


def wrap_svg(width, height, body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
            f'viewBox="0 0 {width} {height}" font-family="{FONT}">\n'
            f'<rect x="0" y="0" width="{width}" height="{height}" fill="white"/>\n'
            f'{arrow_defs()}\n{body}\n</svg>')
