import sys
from playwright.sync_api import sync_playwright

def render(svg_path, png_path, width, height, scale=2):
    with open(svg_path, "r", encoding="utf-8") as f:
        svg = f.read()
    html = f"""<!doctype html><html><head><meta charset="utf-8">
    <style>html,body{{margin:0;padding:0;background:white;}}</style>
    </head><body>{svg}</body></html>"""
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=scale)
        page.set_content(html)
        page.wait_for_timeout(50)
        page.screenshot(path=png_path, clip={"x": 0, "y": 0, "width": width, "height": height})
        browser.close()

if __name__ == "__main__":
    svg_path, png_path, width, height = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    render(svg_path, png_path, width, height)
    print("rendered", png_path)
